<?php

    $url=$_SERVER['REQUEST_URI'];
    $page=substr($url,strpos($url,'=')+1);

    session_start();
    if($_SESSION['user'] == ''){
        header('location:index.php');
    }
?>
<html lang="en">
    <head>
        <?php
            include "includes/_head.php";
        ?>
    </head>
    <body class="page-header-fixed ">
        <?php
            include "includes/_top.php";
        ?>
        <div class="clearfix">
        </div>
        <div class="page-container">
            <?php
                include "includes/sidenav.php";
            ?>
            <div class="page-content-wrapper">
                <div class="page-content">
                    
                    <?php
                        include "includes/".$page.".php";
                        include "includes/footer.php";
                    ?>
                </div>
            </div>
        </div>
        <?php
            include "includes/scripts.php";
        ?>
    </body>
</html>
