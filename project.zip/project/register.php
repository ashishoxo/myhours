<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from adminbag-v1.2.bittyfox.com/default/green-blue/register.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 02 Apr 2017 05:48:40 GMT -->
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Admin-Bag</title>
<!-- Bootstrap -->
<link href="assets/css/bootstrap.min.css" rel="stylesheet">
<!-- icheck -->
<link href="assets/css/skins/all.css" rel="stylesheet">
<!-- slimscroll -->
<link href="assets/css/jquery.slimscroll.css" rel="stylesheet">
<!-- Fontes -->
<link href="assets/css/font-awesome.min.css" rel="stylesheet">
<link href="assets/css/simple-line-icons.css" rel="stylesheet">
<!-- all buttons css -->
<link href="assets/css/buttons.css" rel="stylesheet">
<!-- adminbag main css -->
<link href="assets/css/main.css" rel="stylesheet">
<!-- white blue theme css -->
<link href="assets/css/green-blue.css" rel="stylesheet">
<!-- media css for responsive  -->
<link href="assets/css/main.media.css" rel="stylesheet">
<!--[if lt IE 9]> <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script> <![endif]-->
<!--[if lt IE 9]> <script src="dist/html5shiv.js"></script> <![endif]-->
</head>
<body class="green-bg login">
<div class="middle-box text-center loginscreen   ">
  <div class="widgets-container">
    <div>
     <!--  <h1 class="logo-name">A-BAG</h1> -->
    </div>
    <h3>Register for new user</h3>
    <p>Create account to see it in action.</p>
    <form action="registerAdmin.php" method="post"  class="m-t">
      <div class="form-group">
      	<label>Name</label>
        <input type="text" name="name" required="" placeholder="Name" class="form-control">
      </div>
      <div class="form-group">
      	<label>Email</label>
        <input type="email" name="email" required="" placeholder="Email" class="form-control">
      </div>
      <div class="form-group">
      	<label>Password</label>
        <input type="password" name="password" required="" placeholder="Password" class="form-control">
      </div>
      <div class="form-group">
      	<label>Repeat Password</label>
        <input type="password" name="re-password" required="" placeholder="Password" class="form-control">
      </div>
      <div class="form-group">
        <div class="i-checks">
          <input type="checkbox" class="iCheck" indeterminate="true">
          Agree the terms and policy </div>
      </div>
      <button class="btn green block full-width m-b" type="submit" name="submit">Register</button>
      <p class="text-muted text-center"><small>Already have an account?</small></p>
      <a href="login.html" class="btn btn-sm btn-white btn-block">Login</a>
    </form>
    <p class="top15"> <small>Admin-Bag is easy to use and customize &copy; 2016-2017</small> </p>
  </div>
</div>
</body>
<!-- Go top -->
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="assets/js/vendor/jquery.min.js"></script>
<!-- icheck -->
<script src="assets/js/vendor/icheck.js"></script>
<!-- bootstrap js -->
<script src="assets/js/vendor/bootstrap.min.js"></script>
<!-- main js -->
<script src="assets/js/main.js"></script>
<script>
        $(document).ready(function(){
            $('.i-checks').iCheck({
                checkboxClass: 'icheckbox_square-green',
                radioClass: 'iradio_square-green',
            });
        });
    </script>

<!-- Mirrored from adminbag-v1.2.bittyfox.com/default/green-blue/register.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 02 Apr 2017 05:48:40 GMT -->
</html>
