<?php
$url=$_SERVER['REQUEST_URI'];
PRINT_R(substr($url,strpos($url,'=')+1));


?>
<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from adminbag-v1.2.bittyfox.com/default/green-blue/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 02 Apr 2017 05:38:01 GMT -->
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Admin-Bag</title>
<!-- Bootstrap -->
<link href="assets/css/bootstrap.min.css" rel="stylesheet">
<!-- slimscroll -->
<link href="assets/css/jquery.slimscroll.css" rel="stylesheet">
<!-- Fontes -->
<link href="assets/css/font-awesome.min.css" rel="stylesheet">
<link href="assets/css/simple-line-icons.css" rel="stylesheet">
<!-- all buttons css -->
<link href="assets/css/buttons.css" rel="stylesheet">
<!-- adminbag main css -->
<link href="assets/css/main.css" rel="stylesheet">
<!-- white blue theme css -->
<link href="assets/css/green-blue.css" rel="stylesheet">
<!-- media css for responsive  -->
<link href="assets/css/main.media.css" rel="stylesheet">
<!--[if lt IE 9]> <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script> <![endif]-->
<!--[if lt IE 9]> <script src="dist/html5shiv.js"></script> <![endif]-->
</head>
<body class="green-bg login" style="background-color:#425655">
<div class="middle-box text-center loginscreen ">
  <div class="widgets-container">
    <div>
      <h1 class="logo-name" style="font-size:64px">MY HOURS</h1>
    </div>
    <h3>Welcome to My Hours</h3>
    <p>This framework is uses to track the personal work speed and time taken to accomplish the tasks.</p>
    <p>Login in. To see it in action.</p>
    <form method="post" action="login.php" class="top15">
      <div class="form-group">
      	<label>USERNAME</label>
        <input type="text" name="username"  placeholder="Username" class="form-control">
      </div>
      <div class="form-group">
      	<label>PASSWORD</label>
        <input type="password" name="password"  placeholder="Password" class="form-control">
      </div>
      <button class="btn green block full-width bottom15" type="submit" name="submit">Login</button>
      <a href="forgotpass.php"><small>Forgot password?</small></a>
      <p class="text-muted text-center"><small>Do not have an account?</small></p>
      <a href="register.php" class="btn btn-sm btn-white btn-block">Create an account</a>
    </form>
    <p class="top15"> <small>My Hours is easy to use and customize &copy; 2017-2018</small> </p>
  </div>
</div>
</body>

<!-- Mirrored from adminbag-v1.2.bittyfox.com/default/green-blue/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 02 Apr 2017 05:38:01 GMT -->
</html>
