<?php
	
	if(isset($_POST['submit'])){

		if($_POST['username'] == 'admin' && $_POST['password'] == '123456'){

			session_start();
			$_SESSION['user'] = $_POST['username'];
			header('location:home.php');
		}else{

			echo "Wrong user details!";
		}
	}

?>