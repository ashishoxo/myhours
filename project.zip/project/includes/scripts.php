<script src="assets/js/vendor/jquery.min.js"></script>
        <!-- bootstrap js -->
        <script src="assets/js/vendor/bootstrap.min.js"></script>
        <!--  chartJs js  -->
        <script src="assets/js/vendor/chartJs/Chart.bundle.js"></script>
        <!--timeline_horizontal-->
        <script src="assets/js/vendor/jquery.mobile.custom.min.js"></script>
        <script src="assets/js/vendor/hTimeline.js"></script>
        <!-- amcharts -->
        <script src="assets/js/vendor/amcharts/amcharts.js"></script>
        <script src="assets/js/vendor/amcharts/serial.js"></script>
        <script src="assets/js/vendor/amcharts/pie.js"></script>
        <script src="assets/js/vendor/amcharts/gantt.js"></script>
        <script src="assets/js/vendor/amcharts/funnel.js"></script>
        <script src="assets/js/vendor/amcharts/radar.js"></script>
        <script src="assets/js/vendor/amcharts/amstock.js"></script>
        <script src="assets/js/vendor/amcharts/ammap.js"></script>
        <script src="assets/js/vendor/amcharts/worldLow.js"></script>
        <script src="assets/js/vendor/amcharts/light.js"></script>
        <!-- Peity -->
        <script src="assets/js/vendor/peityJs/jquery.peity.min.js"></script>
        <!-- fullcalendar -->
        <script src='assets/js/vendor/lib/moment.min.js'></script>
        <script src='assets/js/vendor/lib/jquery-ui.custom.min.js'></script>
        <script src='assets/js/vendor/fullcalendar.min.js'></script>
        <!-- icheck -->
        <script src="assets/js/vendor/icheck.js"></script>
        <!-- dataTables-->
        <script type="text/javascript" src="assets/js/vendor/jquery.dataTables.js"></script>
        <script type="text/javascript" src="assets/js/vendor/dataTables.bootstrap.min.js"></script>
        <!-- js for print and download -->
        <script type="text/javascript" src="assets/js/vendor/dataTables.buttons.min.js"></script>
        <script type="text/javascript" src="assets/js/vendor/buttons.flash.min.js"></script>
        <script type="text/javascript" src="assets/js/vendor/jszip.min.js"></script>
        <script type="text/javascript" src="assets/js/vendor/pdfmake.min.js"></script>
        <script type="text/javascript" src="assets/js/vendor/vfs_fonts.js"></script>
        <script type="text/javascript" src="assets/js/vendor/buttons.html5.min.js"></script>
        <script type="text/javascript" src="assets/js/vendor/buttons.print.min.js"></script>
        <script type="text/javascript" src="assets/js/vendor/dataTables.responsive.min.js"></script>
        <script type="text/javascript" src="assets/js/vendor/dataTables.fixedHeader.min.js"></script>
        <!-- dashboard1 js -->
        <script src="assets/js/dashboard1.js"></script>
        <!-- slimscroll js -->
        <script type="text/javascript" src="assets/js/vendor/jquery.slimscroll.js"></script>
        <!-- main js -->
        <script src="assets/js/main.js"></script>
        <!-- adminbag demo js-->
        <script src="assets/js/adminbagdemo.js"></script>