<style type="text/css">
    .page-sidebar .page-sidebar-menu > li.active > a, .page-sidebar .page-sidebar-menu > li.active:hover > a, .page-sidebar-closed.page-sidebar-fixed .page-sidebar:hover .page-sidebar-menu > li.active > a, .page-sidebar-closed.page-sidebar-fixed .page-sidebar:hover .page-sidebar-menu > li.active > a{
            background-color: #208abe;
    }
</style>
<div class="page-sidebar-wrapper">
    <div class="page-sidebar">
        <ul class="page-sidebar-menu  page-header-fixed ">
            <li class="sidebar-search-wrapper">
                <!-- START RESPONSIVE SEARCH FORM -->
                <form class="sidebar-search  " action="http://adminbag-v1.2.bittyfox.com/default/green-blue/search_results.html" method="POST">
                    <a href="javascript:;" class="remove"> <i class="icon-close">
                        </i> </a>
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Search...">
                        <span class="input-group-btn"> <a href="javascript:;" class="btn submit"> <i class="icon-magnifier">
                            </i> </a> </span>
                    </div>
                </form>
                <!-- END RESPONSIVE SEARCH FORM -->
            </li>
            <li class="nav-item active">
                <a class="nav-link nav-toggle" href="javascript:;"> <i class="fa fa-th-large">
                    </i> <span class="title">Track</span> </a>
               
            </li>
            <li class="heading">
                <h3 class="uppercase">
                    Report
                </h3>
            </li>

            </li>
            <li class="nav-item">
                <a class="nav-link nav-toggle" href="javascript:;"> <i class="fa fa-circle">
                    </i> <span class="title">activity</span>  </a>
            </li>
            <li class="nav-item">
                <a class="nav-link nav-toggle" href="javascript:;"> <i class="fa fa-tachometer">
                    </i> <span class="title">Dashboard</span>  </a>
            </li>
            <li class="nav-item">
                <a class="nav-link nav-toggle" href="javascript:;"> <i class="fa fa-circle">
                    </i> <span class="title">Pivot</span> </a>
            </li>
            <li class="nav-item">
                <a class="nav-link nav-toggle" href="javascript:;"> <i class="fa fa-usd">
                    </i> <span class="title">Ecomony</span> </a>
            </li>
            <li class="nav-item">
                <a class="nav-link nav-toggle" href="javascript:;"> <i class="fa fa-money">
                    </i> <span class="title">Budget</span> </a>
            </li>
            <li class="nav-item" style="">
                <a class="nav-link nav-toggle" href="javascript:;"> <i class="icon-layers">
                    </i> <span class="title">Uninvoiced</span> </a>
            </li>

        </ul>
    </div>
</div>